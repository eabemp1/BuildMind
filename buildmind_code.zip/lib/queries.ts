"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  createProjectWithRoadmap,
  deleteProjectForCurrentUser,
  getAICoachAdvice,
  getDashboardOverview,
  getWeeklyReportMetrics,
  clearNotificationsForCurrentUser,
  getNotificationsForCurrentUser,
  getProjectDetail,
  getProjectsForCurrentUser,
  getProjectSummaries,
  markNotificationAsRead,
  updateTaskStatus,
  type BuildMindNotification,
} from "@/lib/buildmind";

export const queryKeys = {
  projects: ["projects"] as const,
  project: (id: string) => ["project", id] as const,
  overview: ["dashboard-overview"] as const,
  weeklyReport: ["weekly-report"] as const,
  notifications: ["notifications"] as const,
  coach: (projectId: string) => ["coach", projectId] as const,
  projectSummaries: ["project-summaries"] as const,
};

export function useProjectsQuery() {
  return useQuery({ queryKey: queryKeys.projects, queryFn: getProjectsForCurrentUser });
}

export function useProjectDetailQuery(projectId: string) {
  return useQuery({
    queryKey: queryKeys.project(projectId),
    queryFn: () => getProjectDetail(projectId),
    enabled: Boolean(projectId),
  });
}

export function useProjectSummariesQuery() {
  return useQuery({ queryKey: queryKeys.projectSummaries, queryFn: getProjectSummaries });
}

export function useDashboardOverviewQuery() {
  return useQuery({ queryKey: queryKeys.overview, queryFn: getDashboardOverview });
}

export function useWeeklyReportMetricsQuery() {
  return useQuery({ queryKey: queryKeys.weeklyReport, queryFn: getWeeklyReportMetrics });
}

export function useNotificationsQuery() {
  return useQuery({ queryKey: queryKeys.notifications, queryFn: getNotificationsForCurrentUser });
}

export function useCreateProjectMutation() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: createProjectWithRoadmap,
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: queryKeys.projects });
      void qc.invalidateQueries({ queryKey: queryKeys.projectSummaries });
      void qc.invalidateQueries({ queryKey: queryKeys.overview });
      void qc.invalidateQueries({ queryKey: queryKeys.notifications });
    },
  });
}

export function useDeleteProjectMutation() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (projectId: string) => deleteProjectForCurrentUser(projectId),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: queryKeys.projects });
      void qc.invalidateQueries({ queryKey: queryKeys.projectSummaries });
      void qc.invalidateQueries({ queryKey: queryKeys.overview });
    },
  });
}

export function useMarkNotificationMutation() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => Promise.resolve(markNotificationAsRead(id)),
    onMutate: async (id) => {
      await qc.cancelQueries({ queryKey: queryKeys.notifications });
      const previous = qc.getQueryData<BuildMindNotification[]>(queryKeys.notifications) ?? [];
      qc.setQueryData<BuildMindNotification[]>(
        queryKeys.notifications,
        previous.map((n) => (n.id === id ? { ...n, is_read: true } : n)),
      );
      return { previous };
    },
    onError: (_err, _id, ctx) => {
      if (ctx?.previous) qc.setQueryData(queryKeys.notifications, ctx.previous);
    },
    onSettled: () => void qc.invalidateQueries({ queryKey: queryKeys.notifications }),
  });
}

export function useClearNotificationsMutation() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => Promise.resolve(clearNotificationsForCurrentUser()),
    onSuccess: () => void qc.invalidateQueries({ queryKey: queryKeys.notifications }),
  });
}

/**
 * useUpdateTaskMutation — marks a task complete/incomplete.
 * On success, invalidates project detail AND project summaries
 * so the stage updates everywhere immediately.
 */
export function useUpdateTaskMutation(projectId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (payload: { taskId: string; isCompleted: boolean; notes?: string }) =>
      updateTaskStatus(payload.taskId, payload.isCompleted, payload.notes),
    onMutate: async (variables) => {
      // Optimistic update: flip the task in cache immediately
      await qc.cancelQueries({ queryKey: queryKeys.project(projectId) });
      const prev = qc.getQueryData(queryKeys.project(projectId));
      qc.setQueryData(queryKeys.project(projectId), (old: ReturnType<typeof getProjectDetail> extends Promise<infer T> ? T : never) => {
        if (!old) return old;
        return {
          ...old,
          tasks: old.tasks.map((t) =>
            t.id === variables.taskId ? { ...t, is_completed: variables.isCompleted, notes: variables.notes ?? t.notes } : t
          ),
        };
      });
      return { prev };
    },
    onError: (_err, _vars, ctx) => {
      if (ctx?.prev) qc.setQueryData(queryKeys.project(projectId), ctx.prev);
    },
    onSettled: () => {
      // Invalidate everything so stage recomputes everywhere
      void qc.invalidateQueries({ queryKey: queryKeys.project(projectId) });
      void qc.invalidateQueries({ queryKey: queryKeys.projectSummaries });
      void qc.invalidateQueries({ queryKey: queryKeys.overview });
    },
  });
}

export function useAICoachQuery(projectId: string) {
  return useQuery({
    queryKey: queryKeys.coach(projectId),
    queryFn: () => getAICoachAdvice(projectId),
    enabled: Boolean(projectId),
    staleTime: 5 * 60 * 1000, // 5 min
  });
}

import { NextResponse } from "next/server";
import { enforceAndTrackAIUsage, groqJSON, hasAdminEnv } from "@/app/api/ai/_utils";
import { createAdminClient } from "@/lib/supabase/admin";
import { getRouteUser } from "@/app/api/ai/_planCheck";

async function scrapeCompetitors(query: string): Promise<{ title: string; url: string; snippet: string }[]> {
  try {
    const encoded = encodeURIComponent(query);
    const res = await fetch(`https://lite.duckduckgo.com/lite/?q=${encoded}`, {
      headers: { "User-Agent": "Mozilla/5.0", "Accept-Language": "en-US,en;q=0.9" },
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) return [];
    const html = await res.text();
    const linkMatches = [...html.matchAll(/class="result-link"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi)];
    const snippetMatches = [...html.matchAll(/class="result-snippet"[^>]*>([\s\S]*?)<\/td>/gi)];
    const results: { title: string; url: string; snippet: string }[] = [];
    for (let i = 0; i < Math.min(linkMatches.length, 6); i++) {
      const href = linkMatches[i]?.[1] ?? "";
      const rawTitle = (linkMatches[i]?.[2] ?? "").replace(/<[^>]+>/g, "").trim();
      const rawSnippet = (snippetMatches[i]?.[1] ?? "").replace(/<[^>]+>/g, "").trim();
      let url = href;
      if (href.includes("uddg=")) {
        const match = href.match(/uddg=([^&]+)/);
        if (match?.[1]) url = decodeURIComponent(match[1]);
      }
      if (!url.startsWith("http") || !rawTitle) continue;
      results.push({ title: rawTitle, url, snippet: rawSnippet });
    }
    return results;
  } catch { return []; }
}

/**
 * signalScore — computes a 0–100 survival probability signal from real project data.
 *
 * Weights (total = 100):
 *   30% task completion rate        — are they actually executing?
 *   25% milestone completion rate   — are they hitting milestones?
 *   20% validation strengths        — evidence of market demand (capped at 4 strengths)
 *   10% weakness penalty            — each weakness subtracts signal
 *   10% execution score             — project-level exec score from Supabase
 *   5%  validation score            — project-level val score from Supabase
 *
 * Stage adjustment (additive, reflects baseline expectation per stage):
 *   Idea        → +0  (everything is uncertain, no bonus)
 *   Validation  → +5  (if you're validating, you're ahead of most)
 *   MVP         → +8  (you built something real)
 *   Launch      → +12 (you've shipped publicly)
 *   Growth      → +15 (you have real users)
 *   Revenue     → +18 (you have paying customers)
 *
 * Result is clamped to [3, 97] — never 0% or 100% (too absolute).
 */
function signalScore(
  taskRate: number,
  milestoneRate: number,
  strengths: string[],
  weaknesses: string[],
  execScore: number,
  valScore: number,
  stage = "Idea",
): number {
  const stageBonus: Record<string, number> = {
    Idea: 0, Validation: 5, MVP: 8, Launch: 12, Growth: 15, Revenue: 18,
  };
  const bonus = stageBonus[stage] ?? 0;

  const raw =
    taskRate * 0.30 +
    milestoneRate * 0.25 +
    Math.min(strengths.length * 5, 20) * 0.20 +
    Math.max(0, 10 - weaknesses.length * 2) * 0.10 +
    execScore * 0.10 +
    valScore * 0.05;

  return Math.min(97, Math.max(3, Math.round(raw + bonus)));
}

function previewSignalScore(idea: string, focusAreas: string[], stage = "Idea"): number {
  const words = idea.split(/\s+/).filter(Boolean).length;
  const hasUser = /\b(for|helps|founders|teams|students|businesses|users|customers|creators|developers)\b/i.test(idea);
  const hasProblem = /\b(problem|struggle|pain|waste|slow|expensive|hard|difficult|manual|risk)\b/i.test(idea);
  const hasBusiness = /\b(pay|paid|revenue|subscription|pricing|sell|customer|market)\b/i.test(idea);
  const stageBonus: Record<string, number> = { Idea: 0, Validation: 5, MVP: 9, Launch: 13, Growth: 16, Revenue: 20 };

  const raw =
    18 +
    Math.min(18, words * 0.45) +
    (hasUser ? 12 : 0) +
    (hasProblem ? 12 : 0) +
    (hasBusiness ? 10 : 0) +
    Math.min(8, focusAreas.length * 2) +
    (stageBonus[stage] ?? 0);

  return Math.min(82, Math.max(12, Math.round(raw)));
}

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => ({}));
    const userId = String(body?.userId ?? "").trim();
    const projectId = String(body?.projectId ?? "").trim();
    // Input length limits — prevent prompt injection and runaway token costs
    const idea = String(body?.idea ?? "").trim().slice(0, 1000);
    const focusAreas = Array.isArray(body?.focusAreas) ? body.focusAreas.map(String).filter(Boolean).slice(0, 10) : [];
    if (!userId) return NextResponse.json({ success: false, error: "userId is required" }, { status: 400 });
    if (!projectId && !idea) return NextResponse.json({ success: false, error: "projectId or idea is required" }, { status: 400 });

    const routeUser = await getRouteUser();
    if (!routeUser || routeUser.userId !== userId) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    if (routeUser.plan !== "builder") {
      const previewScore = previewSignalScore(idea, focusAreas, String(body?.stage ?? "Idea"));
      return NextResponse.json({
        success: true,
        data: {
          gated: true,
          reasoning: [
            "Free preview uses only your written idea, not full project history",
            "Builder unlocks competitor scan, project execution data, and full risk breakdown",
            `Preview signal score ${previewScore}`,
          ],
          verdict: "Preview only: this idea has enough signal to inspect, but the full stress test is Builder-only.",
          kill_reasons: [
            "The preview cannot verify demand, execution history, or competitive pressure without Builder analysis.",
          ],
          survive_reasons: [
            previewScore >= 50 ? "Your description includes some useful market signal." : "You are stress-testing before overbuilding, which is already a good sign.",
          ],
          brutal_advice: "Upgrade to Builder to run the full adversarial analysis with competitor scan and project data.",
          survival_probability: previewScore,
          competitor_summary: "Locked in preview. Builder runs the live competitor scan.",
          differentiation_plan: ["Locked in preview. Builder unlocks the differentiation plan."],
        },
      });
    }

    await enforceAndTrackAIUsage(userId);

    if (!projectId) {
      const competitors = await scrapeCompetitors(`${idea} startup tool software competitors`);
      const competitorContext = competitors.length > 0
        ? `\nLive competitor data from DuckDuckGo:\n${competitors.map((c, i) => `${i + 1}. ${c.title} — ${c.url}\n   ${c.snippet}`).join("\n")}`
        : "\nNo direct competitors found in DuckDuckGo search.";
      const baseSignal = signalScore(0, 0, [], [], 0, 0, "Idea");
      const defaultResult = {
        reasoning: [`Read custom idea context`, `Found ${competitors.length} competitor(s) via DuckDuckGo`, `Signal score ${baseSignal}`, "Identifying the riskiest assumptions"],
        verdict: "This idea needs sharper validation before you build more. The biggest risk is not whether it can be built, but whether a specific group urgently wants it.",
        kill_reasons: ["No project execution data is attached to this custom test", "No user interview or willingness-to-pay evidence was provided", "Competitive differentiation is still unclear"],
        survive_reasons: ["You are stress-testing before overbuilding", "A focused niche could still make this viable"],
        brutal_advice: "Before writing more code, talk to 5 target users and get exact quotes about how they solve this today.",
        survival_probability: baseSignal,
        competitor_summary: competitors.length > 0 ? `DuckDuckGo found ${competitors.length} related products or pages. Treat this as proof of demand and a warning to narrow your positioning.` : "DuckDuckGo did not find clear direct competitors. Use more specific market terms for a better scan.",
        differentiation_plan: ["Pick one narrow user segment and ignore everyone else for 30 days", "Position around the painful workflow competitors underserve", "Validate one differentiated promise with 5 users this week"],
      };

      let result = defaultResult;
      try {
        const ai = await groqJSON<typeof defaultResult>(
          `You are a brutally honest startup advisor. Return ONLY valid JSON with keys: reasoning, verdict, kill_reasons, survive_reasons, brutal_advice, survival_probability, competitor_summary, differentiation_plan.
Use the DuckDuckGo competitor data. No markdown.`,
          `Startup idea:
${idea}

Focus areas: ${focusAreas.join(", ") || "Everything"}
Signal score baseline: ${baseSignal}
${competitorContext}`,
        );
        if (ai?.verdict && typeof ai.survival_probability === "number") {
          result = { ...defaultResult, ...ai };
        }
      } catch { /* use default */ }

      return NextResponse.json({ success: true, data: { ...result, competitors } });
    }

    if (!hasAdminEnv()) {
      // Even without Supabase, compute a minimal signal from request body hints
      const hintStage = String(body?.stage ?? "Idea");
      const hintScore = signalScore(0, 0, [], [], 0, 0, hintStage);
      return NextResponse.json({ success: true, data: {
        reasoning: ["Supabase not configured — cannot read live project data", "Using stage-based baseline estimate"],
        verdict: "Connect Supabase to get a real analysis. Right now we can only see your project stage.",
        kill_reasons: ["No user interviews recorded", "No paying customers yet", "Validation data unavailable — configure Supabase"],
        survive_reasons: ["Founder is actively analyzing risks", "Stage-based signal suggests early momentum"],
        brutal_advice: "Add your SUPABASE_SERVICE_ROLE_KEY to env vars — then run this again for real data.",
        survival_probability: hintScore,
        differentiation_plan: ["Identify one thing none of your 3 closest competitors do", "Make that your only marketing message for 30 days", "Price differently — not cheaper, differently positioned"],
        competitors: [], competitor_summary: "Configure Supabase to enable live competitor scan.",
      }});
    }

    const supabase = createAdminClient();
    const { data: project, error: projectError } = await supabase
      .from("projects")
      .select("title,description,target_users,problem,startup_stage,validation_strengths,validation_weaknesses,validation_score,execution_score")
      .eq("id", projectId).eq("user_id", userId).single();
    if (projectError) throw new Error(projectError.message);

    const { data: milestones } = await supabase.from("milestones").select("id,title,status").eq("project_id", projectId);
    const milestoneIds = (milestones ?? []).map(m => m.id);
    
    // Batch milestone IDs to avoid URL length limits
    let allTasks: Array<{ title: string; is_completed: boolean }> = [];
    if (milestoneIds.length > 0) {
      const BATCH_SIZE = 20;
      const batches = [];
      for (let i = 0; i < milestoneIds.length; i += BATCH_SIZE) {
        const batchIds = milestoneIds.slice(i, i + BATCH_SIZE);
        batches.push(
          supabase.from("tasks").select("title,is_completed").in("milestone_id", batchIds)
        );
      }
      const batchResults = await Promise.all(batches);
      for (const result of batchResults) {
        if (result.data) allTasks = allTasks.concat(result.data);
      }
    }
    const { data: tasks } = { data: allTasks };

    const completedTasks = (tasks ?? []).filter(t => t.is_completed).length;
    const totalTasks = (tasks ?? []).length;
    const completedMilestones = (milestones ?? []).filter(m => m.status === 'completed').length;
    const totalMilestones = (milestones ?? []).length;
    const taskRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
    const milestoneRate = totalMilestones > 0 ? Math.round((completedMilestones / totalMilestones) * 100) : 0;
    const strengths = project.validation_strengths ?? [];
    const weaknesses = project.validation_weaknesses ?? [];
    const stage = project.startup_stage ?? "Idea";
    const execScore = project.execution_score ?? 0;
    const valScore = project.validation_score ?? 0;
    const baseSignal = signalScore(taskRate, milestoneRate, strengths, weaknesses, execScore, valScore, stage);

    const [directResults, broadResults] = await Promise.allSettled([
      scrapeCompetitors(`${project.title ?? ""} ${project.problem ?? ""} startup site:producthunt.com OR site:crunchbase.com`),
      scrapeCompetitors(`${project.problem ?? project.description ?? ""} startup tool software`),
    ]);

    const rawCompetitors = [
      ...(directResults.status === "fulfilled" ? directResults.value : []),
      ...(broadResults.status === "fulfilled" ? broadResults.value : []),
    ];
    const seen = new Set<string>();
    const competitors = rawCompetitors.filter(c => {
      try { const d = new URL(c.url).hostname; if (seen.has(d)) return false; seen.add(d); return true; } catch { return false; }
    }).slice(0, 5);

    const competitorContext = competitors.length > 0
      ? `\nLive competitor data:\n${competitors.map((c, i) => `${i + 1}. ${c.title} — ${c.url}\n   ${c.snippet}`).join("\n")}`
      : "\nNo direct competitors found in live search.";

    const systemPrompt = `You are a brutally honest startup advisor. Return ONLY valid JSON with exactly these keys:
{
  "reasoning": ["step 1 (8-15 words)", "step 2", "step 3", "step 4"],
  "verdict": "2-3 honest sentences about this specific startup",
  "kill_reasons": ["reason 1", "reason 2", "reason 3"],
  "survive_reasons": ["reason 1", "reason 2"],
  "brutal_advice": "the single most important thing to do RIGHT NOW — be specific",
  "survival_probability": <integer 0-100 based on real signals, never 20 as default>,
  "competitor_summary": "1-2 sentences on competitive landscape from live data",
  "differentiation_plan": [
    "Specific thing competitors are NOT doing that this founder could own",
    "How to position differently — not cheaper, but differently angled",
    "One concrete action to stand out in the next 30 days"
  ]
}

survival_probability: base on signal score ${baseSignal}. Adjust up/down based on data quality.
differentiation_plan: MUST be specific to this startup's actual problem/target users and the live competitors found. Not generic. Reference actual competitor names if found.
No preamble. No markdown. Only JSON.`;

    const userPrompt = `Startup: ${project.title ?? "Untitled"}
Problem: ${project.problem ?? "Not defined"}
Target users: ${project.target_users ?? "Not defined"}
Description: ${project.description ?? "Not defined"}
Stage: ${stage} | Exec score: ${execScore}/100 | Val score: ${valScore}/100
Tasks: ${completedTasks}/${totalTasks} (${taskRate}%) | Milestones: ${completedMilestones}/${totalMilestones} (${milestoneRate}%)
Strengths: ${strengths.join(", ") || "None"} | Weaknesses: ${weaknesses.join(", ") || "None"}
Signal score: ${baseSignal}
${competitorContext}`;

    const defaultResult = {
      reasoning: [`Reading ${completedTasks}/${totalTasks} tasks`, `Found ${competitors.length} competitor(s) via live web scan`, `Signal score ${baseSignal}`, "Identifying kill risk and differentiation path"],
      verdict: "Analysis temporarily unavailable.",
      kill_reasons: ["Execution data insufficient", "Validation not confirmed", "Competitive landscape unclear"],
      survive_reasons: ["Founder is analyzing risks proactively"],
      brutal_advice: "Talk to 10 real potential users this week.",
      survival_probability: baseSignal,
      competitor_summary: competitors.length > 0 ? `Found ${competitors.length} potential competitors — differentiation is critical.` : "No clear competitors found — needs more specific search terms.",
      differentiation_plan: ["Identify what each competitor ignores in their product", "Find the user segment they serve badly and own that segment completely", "Build one feature or workflow no competitor has, validate it with 5 users this week"],
    };

    let result = defaultResult;
    try {
      const ai = await groqJSON<typeof defaultResult>(systemPrompt, userPrompt);
      if (ai?.verdict && typeof ai.survival_probability === "number") {
        result = {
          ...ai,
          survival_probability: Math.min(100, Math.max(1, Math.round(ai.survival_probability))),
          reasoning: Array.isArray(ai.reasoning) && ai.reasoning.length > 0 ? ai.reasoning : defaultResult.reasoning,
          differentiation_plan: Array.isArray(ai.differentiation_plan) && ai.differentiation_plan.length > 0 ? ai.differentiation_plan : defaultResult.differentiation_plan,
        };
      }
    } catch { /* use default */ }

    return NextResponse.json({ success: true, data: { ...result, competitors } });
  } catch (error) {
    const msg = error instanceof Error ? error.message : "Analysis failed";
    return NextResponse.json({ success: false, error: msg }, { status: msg.toLowerCase().includes("limit") ? 429 : 500 });
  }
}

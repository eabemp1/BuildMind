/**
 * lib/onboarding-analytics.ts — Funnel & Drop-off Tracker
 *
 * Tracks where users drop off in the onboarding funnel and in-app.
 * All data is localStorage-based (no backend needed).
 * Owner Panel reads this for the analytics tab.
 *
 * Funnel steps (in order):
 *   landing → signup → onboarding_start → onboarding_idea →
 *   onboarding_stage → onboarding_complete → first_today →
 *   first_action_done → first_reflect → first_report →
 *   upgrade_seen → upgrade_converted
 */

import { storage } from "@/lib/storage";

export type FunnelStep =
  | "landing"
  | "signup"
  | "onboarding_start"
  | "onboarding_idea"
  | "onboarding_stage"
  | "stage_selected"
  | "reflexion_strike_started"
  | "reflexion_strike_shown"
  | "reflexion_strike_fallback"
  | "reflexion_strike_accepted"
  | "depth_questions_answered"
  | "onboarding_complete"
  | "first_today"
  | "first_task_completed"
  | "first_action_done"
  | "first_reflect"
  | "first_report"
  | "upgrade_seen"
  | "upgrade_converted";

export interface FunnelEvent {
  step: FunnelStep;
  ts: number;
  meta?: Record<string, string | number | boolean>;
}

export interface SessionEvent {
  type: string;
  page: string;
  ts: number;
  meta?: Record<string, string | number | boolean>;
}

const FUNNEL_KEY   = "bm_funnel";
const SESSION_KEY  = "bm_session_events";
const PAGE_KEY     = "bm_page_views";
const MAX_SESSIONS = 200;

// ── Funnel tracking ───────────────────────────────────────────────────────────

export function getFunnelEvents(): FunnelEvent[] {
  if (typeof window === "undefined") return [];
  return storage.getJSON<FunnelEvent[]>(FUNNEL_KEY, []);
}

export function trackFunnelStep(step: FunnelStep, meta?: FunnelEvent["meta"]): void {
  if (typeof window === "undefined") return;
  const events = getFunnelEvents();
  if (events.find(e => e.step === step)) return;
  events.push({ step, ts: Date.now(), meta });
  storage.setJSON(FUNNEL_KEY, events);

  // Growth #5: dual-write to server for real analytics — fire-and-forget
  try {
    let sessionId = storage.getJSON<string>("bm_session_id", "");
    if (!sessionId) {
      sessionId = Math.random().toString(36).slice(2) + Date.now().toString(36);
      storage.setJSON("bm_session_id", sessionId);
    }
    fetch("/api/analytics/funnel", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        step,
        meta,
        sessionId,
        referrer: document.referrer?.slice(0, 200) || undefined,
      }),
    }).catch(() => {}); // analytics must never block UX
  } catch {
    // non-critical
  }
}

export function getFunnelSummary(): {
  step: FunnelStep;
  reached: boolean;
  ts?: number;
  label: string;
  icon: string;
}[] {
  const events = getFunnelEvents();
  const reached = new Map(events.map(e => [e.step, e.ts]));

  const STEPS: { step: FunnelStep; label: string; icon: string }[] = [
    { step: "landing",             label: "Visited landing",       icon: "🌐" },
    { step: "signup",              label: "Signed up",             icon: "📝" },
    { step: "onboarding_start",    label: "Started onboarding",    icon: "🚪" },
    { step: "onboarding_idea",     label: "Entered idea",          icon: "💡" },
    { step: "onboarding_stage",    label: "Selected stage",        icon: "📊" },
    { step: "onboarding_complete", label: "Completed onboarding",  icon: "✅" },
    { step: "first_today",         label: "Visited Today page",    icon: "⚡" },
    { step: "first_action_done",   label: "Completed first action","icon": "🎯" },
    { step: "first_reflect",       label: "Reflected once",        icon: "🧠" },
    { step: "first_report",        label: "Viewed report",         icon: "📋" },
    { step: "upgrade_seen",        label: "Saw upgrade page",      icon: "💳" },
    { step: "upgrade_converted",   label: "Upgraded to Builder",   icon: "👑" },
  ];

  return STEPS.map(s => ({
    ...s,
    reached: reached.has(s.step),
    ts: reached.get(s.step),
  }));
}

// ── Page view tracking ────────────────────────────────────────────────────────

export interface PageView {
  path: string;
  count: number;
  lastVisit: number;
  firstVisit: number;
}

export function trackPageView(path: string): void {
  if (typeof window === "undefined") return;
  const views = storage.getJSON<Record<string, PageView>>(PAGE_KEY, {});
  const existing = views[path];
  const now = Date.now();
  views[path] = existing
    ? { ...existing, count: existing.count + 1, lastVisit: now }
    : { path, count: 1, firstVisit: now, lastVisit: now };
  storage.setJSON(PAGE_KEY, views);
}

export function getPageViews(): PageView[] {
  if (typeof window === "undefined") return [];
  const views = storage.getJSON<Record<string, PageView>>(PAGE_KEY, {});
  return Object.values(views).sort((a, b) => b.count - a.count);
}

// ── Session events ────────────────────────────────────────────────────────────

export function trackEvent(type: string, page: string, meta?: SessionEvent["meta"]): void {
  if (typeof window === "undefined") return;
  const events = storage.getJSON<SessionEvent[]>(SESSION_KEY, []);
  events.unshift({ type, page, ts: Date.now(), meta });
  storage.setJSON(SESSION_KEY, events.slice(0, MAX_SESSIONS));
}

export function getRecentEvents(limit = 20): SessionEvent[] {
  if (typeof window === "undefined") return [];
  return storage.getJSON<SessionEvent[]>(SESSION_KEY, []).slice(0, limit);
}

// ── Drop-off analysis ─────────────────────────────────────────────────────────

export function getDropOffStep(): { step: FunnelStep | null; label: string } {
  const summary = getFunnelSummary();
  const lastReached = [...summary].reverse().find(s => s.reached);
  const nextStep = summary.find(s => !s.reached);

  if (!lastReached) return { step: null, label: "User hasn't started the funnel" };
  if (!nextStep) return { step: null, label: "Completed full funnel 🎉" };

  return { step: nextStep.step, label: `Dropped before: ${nextStep.label}` };
}

// ── Auto page tracker hook (call in layout) ───────────────────────────────────

export function usePageTracking(path: string): void {
  if (typeof window === "undefined") return;
  // Map paths to funnel steps
  const STEP_MAP: Partial<Record<string, FunnelStep>> = {
    "/landing":    "landing",
    "/":           "landing",
    "/onboarding": "onboarding_start",
    "/today":      "first_today",
    "/reports":    "first_report",
    "/upgrade":    "upgrade_seen",
  };
  const step = STEP_MAP[path];
  if (step) trackFunnelStep(step);
  trackPageView(path);
}

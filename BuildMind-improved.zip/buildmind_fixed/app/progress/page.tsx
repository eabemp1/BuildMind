/**
 * app/progress/page.tsx
 *
 * Product Improvement #1 — Nav collapse: Progress replaces Reports + Insights
 * as a single destination with two tabs:
 *
 *   "This Week"  — the weekly report (previously /reports)
 *   "Patterns"   — behavioral insights (previously /insights)
 *
 * Both tabs respect the BuildMindCalibrating gate (<7 reflections → show
 * the calibrating component instead of thin content).
 */

"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { createClient } from "@/lib/supabase/client";
import { BuildMindCalibrating } from "@/components/BuildMindCalibrating";

// ── Lazy-loaded tab content ───────────────────────────────────────────────────
// We import the existing page components directly to avoid duplication.
// In production these would be refactored into shared components; here we
// inline lightweight versions that pull from the same data layer.

function ThisWeekTab({ reflectionCount }: { reflectionCount: number }) {
  if (reflectionCount < 7) {
    return <BuildMindCalibrating count={reflectionCount} surface="insights" />;
  }
  return (
    <div style={{ padding: "0 0 32px" }}>
      {/* Dynamically load the weekly report iframe to avoid duplicating the component */}
      <iframe
        src="/reports?embed=1"
        style={{
          width: "100%",
          minHeight: 600,
          border: "none",
          borderRadius: 12,
          background: "var(--bm-bg)",
        }}
        title="Weekly Report"
      />
    </div>
  );
}

function PatternsTab({ reflectionCount }: { reflectionCount: number }) {
  if (reflectionCount < 7) {
    return <BuildMindCalibrating count={reflectionCount} surface="patterns" />;
  }
  return (
    <div style={{ padding: "0 0 32px" }}>
      <iframe
        src="/insights?embed=1"
        style={{
          width: "100%",
          minHeight: 600,
          border: "none",
          borderRadius: 12,
          background: "var(--bm-bg)",
        }}
        title="Patterns"
      />
    </div>
  );
}

type Tab = "week" | "patterns";

export default function ProgressPage() {
  const [activeTab, setActiveTab] = useState<Tab>("week");
  const [reflectionCount, setReflectionCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const supabase = createClient();
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) { setLoading(false); return; }
        const { count } = await supabase
          .from("reflections")
          .select("id", { count: "exact", head: true })
          .eq("user_id", user.id);
        setReflectionCount(count ?? 0);
      } catch {
        // Non-fatal
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const TABS: { id: Tab; label: string; desc: string }[] = [
    { id: "week",     label: "This Week",  desc: "Performance and momentum" },
    { id: "patterns", label: "Patterns",   desc: "Your behavioral signature" },
  ];

  return (
    <div style={{ maxWidth: 760, margin: "0 auto", padding: "28px 16px 48px" }}>
      {/* Page header */}
      <div style={{ marginBottom: 24 }}>
        <p style={{
          fontSize: 10, fontWeight: 700, color: "var(--bm-text4)",
          textTransform: "uppercase", letterSpacing: "0.1em", margin: "0 0 5px",
        }}>
          BuildMind
        </p>
        <h1 style={{
          fontSize: 26, fontWeight: 700, color: "var(--bm-text)",
          letterSpacing: "-0.03em", margin: 0,
        }}>
          Progress
        </h1>
      </div>

      {/* Tab bar */}
      <div
        style={{
          display: "flex",
          gap: 0,
          background: "var(--bm-bg2)",
          border: "1px solid var(--bm-border)",
          borderRadius: 12,
          padding: 4,
          marginBottom: 24,
        }}
      >
        {TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            style={{
              flex: 1,
              padding: "9px 16px",
              borderRadius: 9,
              border: "none",
              background: activeTab === tab.id ? "var(--bm-bg4)" : "transparent",
              color: activeTab === tab.id ? "var(--bm-text)" : "var(--bm-text3)",
              fontSize: 13,
              fontWeight: activeTab === tab.id ? 600 : 400,
              cursor: "pointer",
              fontFamily: "inherit",
              transition: "all 0.15s",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: 1,
            }}
          >
            <span>{tab.label}</span>
            <span style={{ fontSize: 10, color: activeTab === tab.id ? "var(--bm-text3)" : "var(--bm-text4)", fontWeight: 400 }}>
              {tab.desc}
            </span>
          </button>
        ))}
      </div>

      {/* Tab content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -6 }}
          transition={{ duration: 0.2 }}
        >
          {loading ? (
            <div style={{ textAlign: "center", padding: "64px 0", color: "var(--bm-text4)", fontSize: 13 }}>
              Loading…
            </div>
          ) : activeTab === "week" ? (
            <ThisWeekTab reflectionCount={reflectionCount} />
          ) : (
            <PatternsTab reflectionCount={reflectionCount} />
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

import type { Metadata, Viewport } from "next";
import { headers } from "next/headers";
import "./globals.css";
import Providers from "@/components/providers";
import PwaProvider from "@/components/PwaProvider";

// ─── SEO METADATA ──────────────────────────────────────────────────────────
// Domain: buildmind.live (GitHub Student Developer Pack)
// Strategy: own "founder daily action", "startup accountability app",
//           "solo founder tool", "build in public tracker"
export const metadata: Metadata = {
  metadataBase: new URL("https://buildmind.live"),
  title: {
    default: "BuildMind — Your next move, already decided",
    template: "%s | BuildMind",
  },
  description:
    "BuildMind watches your startup context and tells you the one highest-leverage thing to do next. No lists. No frameworks. Just the next move — decided overnight while you sleep.",
  keywords: [
    "what to do next as a founder",
    "founder decision fatigue",
    "daily action for founders",
    "startup execution tool",
    "solo founder productivity",
    "ai for founders",
    "founder momentum tracker",
    "build in public tracker",
    "indie hacker daily planner",
    "validate startup idea free",
    "startup accountability app",
    "founder daily routine",
    "solofounder app",
    "startup stage tracker",
    "buildmind",
    "build mind app",
    "founder next move",
    "remove decision fatigue startup",
  ],
  authors: [{ name: "BuildMind", url: "https://buildmind.live" }],
  creator: "BuildMind",
  publisher: "BuildMind",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
      "max-video-preview": -1,
    },
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
    apple: "/logo/apple-touch-icon.png",
  },
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "BuildMind",
  },
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://buildmind.live",
    siteName: "BuildMind",
    title: "BuildMind — Your next move, already decided",
    description:
      "BuildMind watches your startup context and tells you the one highest-leverage thing to do next. No lists. No frameworks. Just the next move.",
    images: [
      {
        url: "/logo/buildmind-og-image.svg",
        width: 1200,
        height: 630,
        alt: "BuildMind — The next move, already decided",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "BuildMind — AI Chief of Staff for Stuck Founders",
    description:
      "BuildMind decides the next execution move, stress-tests weak ideas, and keeps founder momentum honest.",
    images: ["/logo/buildmind-og-image.svg"],
    creator: "@buildmind_os",
  },
  // canonical is set per-page via metadata.alternates in each page file
  verification: {
    // Add your Google Search Console verification token here
    // google: "YOUR_GOOGLE_VERIFICATION_TOKEN",
  },
};

export const viewport: Viewport = {
  themeColor: "#0C0D0F",
};

// ─── STRUCTURED DATA (JSON-LD) ─────────────────────────────────────────────
// Multiple schema types = more Google features (rich results, sitelinks, etc.)
const jsonLd = [
  {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    name: "BuildMind",
    applicationCategory: "BusinessApplication",
    operatingSystem: "Web",
    url: "https://buildmind.live",
    description:
      "BuildMind is the AI Chief of Staff for stuck founders. It decides the next execution move, stress-tests weak ideas, and keeps founder momentum honest.",
    featureList: [
      "AI-powered daily action based on startup stage",
      "Reflect loop — yesterday's outcome changes today's action",
      "Founder streak tracking",
      "AI Coach with real project data",
      "Break My Startup — brutal AI stress test",
      "Weekly share card for build-in-public",
    ],
    offers: [
      {
        "@type": "Offer",
        name: "Starter",
        price: "0",
        priceCurrency: "USD",
        description: "7 actions/week, 3 AI Coach messages/week",
      },
      {
        "@type": "Offer",
        name: "Builder",
        price: "39",
        priceCurrency: "USD",
        description: "Unlimited actions, AI Coach, weekly reports, and full Break My Startup analysis",
      },
    ],
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: "4.9",
      reviewCount: "12",
    },
    creator: {
      "@type": "Person",
      name: "BuildMind Team",
      sameAs: "https://x.com/buildmind_os",
    },
  },
  {
    "@context": "https://schema.org",
    "@type": "WebSite",
    url: "https://buildmind.live",
    name: "BuildMind",
    description: "Daily action engine for founders",
  },
  {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: [
      {
        "@type": "Question",
        name: "What is BuildMind?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "BuildMind is the AI Chief of Staff for stuck founders. It decides the next execution move, stress-tests weak ideas, and keeps founder momentum honest.",
        },
      },
      {
        "@type": "Question",
        name: "How is BuildMind different from a to-do app?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "BuildMind doesn't ask you to plan. It tells you what to do. The action is already decided — by AI, based on your startup stage, your project data, and yesterday's reflection. You don't manage a list. You show up and execute.",
        },
      },
      {
        "@type": "Question",
        name: "Is BuildMind free?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "Yes. BuildMind has a free tier with 3 AI Coach messages per week. Builder plan ($39/month) unlocks unlimited actions, the AI Coach, weekly reports, and full Break My Startup analysis.",
        },
      },
      {
        "@type": "Question",
        name: "Who is BuildMind for?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "Solo founders, indie hackers, and first-time entrepreneurs who have an idea or early startup and want to stop planning and start executing. BuildMind works best for people in the idea, validation, prototype, MVP, or launch stage.",
        },
      },
    ],
  },
];

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  // Read the per-request nonce injected by middleware (W5 CSP fix)
  const headersList = await headers();
  const nonce = headersList.get("x-nonce") ?? "";
  return (
    // Some browser extensions (e.g. Grammarly) inject attributes into <body>
    // before React hydrates, which can trigger a hydration mismatch warning.
    <html lang="en" suppressHydrationWarning>
      <head>
        {jsonLd.map((schema, i) => (
          <script
            key={i}
            nonce={nonce}
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
          />
        ))}
        {/* Per-page canonical tags are set via metadata.alternates.canonical in each page */}
        {/* Performance */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Geist:wght@300;400;500;600&family=DM+Serif+Display:ital@0;1&display=swap" />
        {/* Icons */}
        <link rel="icon" type="image/svg+xml" href="/favicon.svg?v=3" />
        <link rel="shortcut icon" href="/favicon.svg?v=3" />
        <link rel="apple-touch-icon" href="/logo/apple-touch-icon.png" />
        {/* Theme */}
        <meta name="theme-color" media="(prefers-color-scheme: light)" content="#f2f3f9" />
        <meta name="theme-color" media="(prefers-color-scheme: dark)" content="#0C0D0F" />
        <meta name="color-scheme" content="light dark" />
        {/* Mobile */}
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="BuildMind" />
        {/* Geo targeting (helps local/regional discovery) */}
        <meta name="geo.region" content="GH" />
      </head>
      <body suppressHydrationWarning>
        <Providers nonce={nonce}>
          <PwaProvider>{children}</PwaProvider>
        </Providers>
      </body>
    </html>
  );
}
